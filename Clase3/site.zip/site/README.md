npm init
create README.md
add repository to package.json
create app.js